<?php
require 'session.php';

if (sudah_login()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$nama = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama  = trim($_POST['nama'] ?? '');
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    $konf  = $_POST['konfirmasi'] ?? '';

    if ($nama === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = 'Nama dan email harus diisi dengan benar.';
    } elseif (strlen($pass) < 6) {
        $error = 'Kata sandi minimal 6 karakter.';
    } elseif ($pass !== $konf) {
        $error = 'Konfirmasi kata sandi tidak sama.';
    } elseif ($email === AKUN_DEMO_EMAIL || isset($_SESSION['akun'][$email])) {
        $error = 'Email sudah terdaftar.';
    } else {
        // Simpan akun di session (tanpa database)
        $_SESSION['akun'][$email] = [
            'nama' => $nama,
            'hash' => password_hash($pass, PASSWORD_DEFAULT),
        ];
        header('Location: login.php?daftar=1');
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Daftar - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">

  <main class="login-card">

    <header class="login-header">
      <a href="index.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
    </header>

    <h1 class="login-banner">Daftar Akun Hunianku</h1>

    <form class="login-form" action="register.php" method="post">
      <?php if ($error): ?>
        <p class="login-error" role="alert"><?= h($error) ?></p>
      <?php endif; ?>

      <div class="form-group">
        <label for="nama">Nama Lengkap</label>
        <input type="text" id="nama" name="nama" placeholder="Masukan Nama Lengkap" value="<?= h($nama) ?>" required>
      </div>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Masukan Email Anda" value="<?= h($email) ?>" required>
      </div>

      <div class="form-group">
        <label for="password">Kata Sandi</label>
        <input type="password" id="password" name="password" placeholder="Buat Kata Sandi" minlength="6" required>
      </div>

      <div class="form-group">
        <label for="konfirmasi">Konfirmasi Kata Sandi</label>
        <input type="password" id="konfirmasi" name="konfirmasi" placeholder="Konfirmasi Kata Sandi" minlength="6" required>
      </div>

      <button type="submit" class="btn-login">Daftar</button>

      <p class="register">Sudah punya akun ? <a href="login.php">Masuk</a></p>
    </form>

  </main>
  <script src="js/common.js"></script>
</body>
</html>