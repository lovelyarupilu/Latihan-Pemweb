<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Entry Kategori - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <img class="dash-avatar dash-avatar-img" src="images/profil.jpg" alt="Foto profil">
      </a>
    </header>

    <div class="dash-body">

      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link active"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <main class="dash-main">

        <p class="entry-breadcrumb">
          <a href="katagori.php">Kategori</a> &rsaquo; <span>Entry Kategori</span>
        </p>
        <h1 class="dash-title">Entry Kategori</h1>

        <div class="entry-layout">

          <!-- FORM ENTRY -->
          <section class="crud-card entry-card">
            <h2 class="dash-subtitle">Data Kategori Baru</h2>

            <form id="form-entry-kategori" class="crud-form" action="#" method="post">
              <div class="form-group">
                <label for="nama">Nama Kategori <span class="req">*</span></label>
                <input type="text" id="nama" name="nama" placeholder="Contoh: Rumah" maxlength="50" required>
                <small class="form-hint">Maksimal 50 karakter.</small>
              </div>

              <div class="form-group">
                <label for="ikon">Ikon</label>
                <select id="ikon" name="ikon">
                  <option value="rumah">Rumah</option>
                  <option value="apartemen">Apartemen</option>
                  <option value="kost">Kost</option>
                  <option value="villa">Villa</option>
                </select>
              </div>

              <div class="form-group">
                <label for="deskripsi">Deskripsi</label>
                <textarea id="deskripsi" name="deskripsi" rows="3" placeholder="Deskripsi singkat kategori" maxlength="150"></textarea>
                <small class="form-hint">Maksimal 150 karakter.</small>
              </div>

              <div class="form-group">
                <span class="entry-label">Status</span>
                <div class="entry-radio">
                  <label><input type="radio" name="status" value="Aktif" checked> Aktif</label>
                  <label><input type="radio" name="status" value="Nonaktif"> Nonaktif</label>
                </div>
              </div>

              <div class="crud-actions">
                <button type="submit" class="btn btn-primary">Simpan</button>
                <button type="reset" class="btn btn-light">Reset</button>
                <a href="katagori.php" class="btn btn-light">Kembali</a>
              </div>
            </form>
          </section>

          <!-- PRATINJAU -->
          <aside class="crud-card entry-preview">
            <h2 class="dash-subtitle">Pratinjau</h2>
            <div class="entry-preview-box">
              <div class="dash-cat">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2 12h3v9h5v-6h4v6h5v-9h3z" fill="#fff"/></svg>
                <span>Kategori</span>
              </div>
            </div>
            <p class="entry-preview-desc">Tampilan kategori seperti di halaman Beranda.</p>
          </aside>

        </div>
      </main>

    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/kategori-entry.js"></script>
</body>
</html>