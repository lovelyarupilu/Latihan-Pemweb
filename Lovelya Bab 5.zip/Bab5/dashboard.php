<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dashboard - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <!-- HEADER -->
    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <img class="dash-avatar dash-avatar-img" src="images/profil.jpg" alt="Foto profil">
      </a>
    </header>

    <div class="dash-body">

      <!-- SIDEBAR -->
      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link active"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <!-- KONTEN -->
      <main class="dash-main">
        <h1 class="dash-title">Selamat Datang, <?= h(nama_user()) ?>!</h1>

        <form class="dash-search" action="#" method="get">
          <input type="text" name="q" placeholder="Cari Hunian Kamu....." aria-label="Cari hunian">
          <button type="submit" aria-label="Cari">
            <svg viewBox="0 0 24 24" width="14" height="14" aria-hidden="true">
              <circle cx="10" cy="10" r="6" fill="none" stroke="#000" stroke-width="3"/>
              <line x1="15" y1="15" x2="22" y2="22" stroke="#000" stroke-width="3" stroke-linecap="round"/>
            </svg>
          </button>
        </form>

        <!-- KATEGORI -->
        <div class="dash-cats">
          <a href="katagori.php" class="dash-cat">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2 12h3v9h5v-6h4v6h5v-9h3z" fill="#fff"/></svg>
            <span>Rumah</span>
          </a>
          <a href="katagori.php" class="dash-cat">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 21V9h7v12zm8 0V3h10v18zM5 11v2h3v-2zm0 4v2h3v-2zm8-9v2h2V6zm4 0v2h2V6zm-4 4v2h2v-2zm4 0v2h2v-2zm-4 4v2h2v-2zm4 0v2h2v-2z" fill="#fff"/></svg>
            <span>Apartemen</span>
          </a>
          <a href="katagori.php" class="dash-cat">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2 12h3v9h14v-9h3zm0 7a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm-1 5h2v4h-2z" fill="#fff"/></svg>
            <span>Kost</span>
          </a>
          <a href="katagori.php" class="dash-cat">
            <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3 2 12h3v9h14v-9h3zm-2 7 6 3.500-6 3.500z" fill="#fff"/></svg>
            <span>Villa</span>
          </a>
        </div>

        <!-- HUNIAN TERBARU -->
        <h2 class="dash-subtitle">Hunian Terbaru</h2>

        <div class="dash-grid">
          <a href="pesan.php" class="dash-card">
            <img src="images/rumah-premium.jpg" alt="Rumah Premium">
            <span class="dash-card-name">Rumah Premium</span>
          </a>
          <a href="pesan.php" class="dash-card">
            <img src="images/apartemen-premium.jpg" alt="Apartemen Premium">
            <span class="dash-card-name">Apartemen Premium</span>
          </a>
          <a href="pesan.php" class="dash-card">
            <img src="images/kost-premium.jpg" alt="Kost Premium">
            <span class="dash-card-name">Kost Premium</span>
          </a>
          <a href="pesan.php" class="dash-card">
            <img src="images/villa-premium.jpg" alt="Villa Premium">
            <span class="dash-card-name">Villa Premium</span>
          </a>
        </div>
      </main>

    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/dashboard.js"></script>
</body>
</html>