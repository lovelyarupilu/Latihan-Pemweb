/* =====================================================
   transaksi.js  -  CRUD Transaksi (transaksi.html)
   - PopUp: confirm (hapus), alert (validasi)
   - Event: submit, click (delegasi), input (cari), change (status), reset
   - Web Storage: data di localStorage
   - Promise + async/await (data kategori diambil lewat HK.db)
   ===================================================== */
"use strict";

const TRANSAKSI_AWAL = [
  { id: 1, tanggal: "2026-09-10", pembeli: "Budi Santoso", hunian: "Modern Minimalis", kategori: "Rumah", harga: 30000000000, status: "Lunas" },
  { id: 2, tanggal: "2026-09-21", pembeli: "Sari Wulandari", hunian: "Apartemen Premium", kategori: "Apartemen", harga: 450000000, status: "Pending" },
  { id: 3, tanggal: "2026-10-02", pembeli: "Andi Pratama", hunian: "Kost Premium", kategori: "Kost", harga: 15000000, status: "Batal" },
];

HK.siap(async () => {
  const form = document.getElementById("form-transaksi");
  if (!form) return;

  const el = {
    id: document.getElementById("transaksi-id"),
    tanggal: document.getElementById("tanggal"),
    pembeli: document.getElementById("pembeli"),
    hunian: document.getElementById("hunian"),
    kategori: document.getElementById("kategori"),
    harga: document.getElementById("harga"),
    status: document.getElementById("status"),
    judul: document.getElementById("form-title"),
    simpan: document.getElementById("btn-simpan"),
    batal: document.getElementById("btn-batal"),
    cari: document.getElementById("cari"),
    tabel: document.getElementById("tabel-transaksi"),
    ringkasan: document.getElementById("ringkasan"),
  };

  /* Muat data secara asynchronous (Promise.all = dua pengambilan sekaligus) */
  const [kategori, hasilData] = await Promise.all([
    HK.db.ambil(HK.KEY.KATEGORI, HK.KATEGORI_AWAL),
    HK.db.ambil(HK.KEY.TRANSAKSI, TRANSAKSI_AWAL),
  ]);
  let data = hasilData;

  /* Isi dropdown kategori dengan kategori yang Aktif */
  kategori
    .filter((k) => k.status === "Aktif")
    .forEach((k) => el.kategori.appendChild(HK.el("option", { attr: { value: k.nama } }, k.nama)));

  async function simpanData() {
    try {
      await HK.db.simpan(HK.KEY.TRANSAKSI, data);
    } catch (err) {
      alert("Gagal menyimpan data: " + err.message);
    }
  }

  /* ---------- Form ---------- */
  function resetForm() {
    form.reset();
    el.id.value = "";
    el.tanggal.value = HK.hariIni();
    el.judul.textContent = "Tambah Transaksi";
    el.simpan.textContent = "Simpan";
  }

  // submit: tambah baru atau perbarui (tergantung ada id atau tidak)
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const harga = Number(el.harga.value);
    if (!el.pembeli.value.trim() || !el.hunian.value.trim()) {
      alert("Nama pembeli dan nama hunian wajib diisi.");
      return;
    }
    if (!Number.isFinite(harga) || harga <= 0) {
      alert("Harga harus lebih dari 0.");
      el.harga.focus();
      return;
    }

    const isi = {
      tanggal: el.tanggal.value,
      pembeli: el.pembeli.value.trim(),
      hunian: el.hunian.value.trim(),
      kategori: el.kategori.value,
      harga,
      status: el.status.value,
    };

    if (el.id.value) {
      const item = data.find((t) => t.id === Number(el.id.value));
      if (item) Object.assign(item, isi);
      HK.toast("Transaksi diperbarui", "success");
    } else {
      data.push(Object.assign({ id: Date.now() }, isi));
      HK.toast("Transaksi ditambahkan", "success");
    }

    await simpanData();
    resetForm();
    render();
  });

  // click Batal: kosongkan form / batalkan mode edit
  el.batal.addEventListener("click", resetForm);

  // change: ingatkan jika status diubah menjadi Batal
  el.status.addEventListener("change", () => {
    if (el.status.value === "Batal") HK.toast("Status diubah ke Batal", "info");
  });

  /* ---------- Tabel ---------- */
  function badge(status) {
    return HK.el("span", { kelas: "badge badge-" + status.toLowerCase() }, status);
  }

  function render() {
    const kata = el.cari.value.trim().toLowerCase();
    const tampil = data.filter((t) =>
      [t.pembeli, t.hunian, t.kategori, t.status].some((v) => v.toLowerCase().includes(kata))
    );

    el.tabel.replaceChildren();

    if (!tampil.length) {
      const tr = HK.el("tr");
      tr.appendChild(HK.el("td", { kelas: "table-empty", attr: { colspan: "8" } }, "Data tidak ditemukan"));
      el.tabel.appendChild(tr);
    }

    tampil.forEach((t, i) => {
      const tr = HK.el("tr");
      [String(i + 1), t.tanggal, t.pembeli, t.hunian, t.kategori, HK.rupiah(t.harga)].forEach((v) =>
        tr.appendChild(HK.el("td", {}, v))
      );

      const tdStatus = HK.el("td");
      tdStatus.appendChild(badge(t.status));
      tr.appendChild(tdStatus);

      const tdAksi = HK.el("td");
      const aksi = HK.el("div", { kelas: "table-actions" });
      aksi.append(
        HK.el("button", { kelas: "btn btn-light btn-sm", attr: { type: "button", "data-aksi": "edit", "data-id": t.id } }, "Edit"),
        HK.el("button", { kelas: "btn btn-danger btn-sm", attr: { type: "button", "data-aksi": "hapus", "data-id": t.id } }, "Hapus")
      );
      tdAksi.appendChild(aksi);
      tr.appendChild(tdAksi);

      el.tabel.appendChild(tr);
    });

    const totalLunas = data.filter((t) => t.status === "Lunas").reduce((a, t) => a + t.harga, 0);
    el.ringkasan.textContent = `Total ${data.length} transaksi | Pendapatan (Lunas): ${HK.rupiah(totalLunas)}`;
  }

  // click (delegasi) untuk tombol Edit / Hapus
  el.tabel.addEventListener("click", async (e) => {
    const btn = e.target.closest("button[data-aksi]");
    if (!btn) return;
    const id = Number(btn.dataset.id);
    const item = data.find((t) => t.id === id);
    if (!item) return;

    if (btn.dataset.aksi === "hapus") {
      // CONFIRM BOX
      if (confirm(`Hapus transaksi "${item.hunian}" milik ${item.pembeli}?`)) {
        data = data.filter((t) => t.id !== id);
        await simpanData();
        render();
        HK.toast("Transaksi dihapus", "info");
      }
    } else {
      // Isi form dengan data yang mau diedit
      el.id.value = item.id;
      el.tanggal.value = item.tanggal;
      el.pembeli.value = item.pembeli;
      el.hunian.value = item.hunian;
      el.harga.value = item.harga;
      el.status.value = item.status;
      // Kategori mungkin sudah dinonaktifkan: tambahkan opsinya bila belum ada
      if (![...el.kategori.options].some((o) => o.value === item.kategori)) {
        el.kategori.appendChild(HK.el("option", { attr: { value: item.kategori } }, item.kategori));
      }
      el.kategori.value = item.kategori;
      el.judul.textContent = "Edit Transaksi";
      el.simpan.textContent = "Perbarui";
      form.scrollIntoView({ behavior: "smooth" });
    }
  });

  // input: cari langsung saat mengetik
  el.cari.addEventListener("input", render);

  resetForm();
  render();
});
