/* =====================================================
   auth.js  -  Halaman login.html & register.html
   - PopUp: alert (daftar berhasil / password beda), prompt (lupa sandi)
   - Event: submit, keyup, keydown, click
   - Web Storage: akun di localStorage, sesi di sessionStorage
   - Promise + async/await
   Catatan: password disimpan polos hanya untuk latihan. Aplikasi nyata
   wajib memakai hashing di sisi server.
   ===================================================== */
"use strict";

HK.siap(() => {
  const formLogin = document.getElementById("login-error") ? document.querySelector(".login-form") : null;
  const formDaftar = document.getElementById("konfirmasi") ? document.querySelector(".login-form") : null;

  if (formLogin) pasangLogin(formLogin);
  if (formDaftar) pasangDaftar(formDaftar);
});

/* ---------------- LOGIN ---------------- */
function pasangLogin(form) {
  const email = document.getElementById("email");
  const pass = document.getElementById("password");
  const galat = document.getElementById("login-error");

  const tampilGalat = (teks) => {
    galat.textContent = teks;
    galat.hidden = !teks;
  };

  // keyup: pesan error hilang saat user mulai mengetik ulang
  [email, pass].forEach((el) => el.addEventListener("keyup", () => tampilGalat("")));

  // keydown: peringatan jika Caps Lock aktif saat mengetik kata sandi
  pass.addEventListener("keydown", (e) => {
    if (e.getModifierState && e.getModifierState("CapsLock")) {
      tampilGalat("Caps Lock sedang aktif");
    }
  });

  // submit: proses masuk (async)
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
    const user = users.find(
      (u) => u.email.toLowerCase() === email.value.trim().toLowerCase() && u.password === pass.value
    );

    if (!user) {
      tampilGalat("Email atau kata sandi salah.");
      HK.toast("Gagal masuk", "error");
      return;
    }

    HK.setSesi(user.email);
    HK.toast(`Selamat datang, ${user.nama}!`, "success");
    await HK.jeda(800); // beri waktu toast terbaca
    window.location.href = "dashboard.html";
  });

  // click: Lupa Kata Sandi -> PROMPT BOX lalu ALERT BOX
  document.querySelector(".forgot").addEventListener("click", (e) => {
    e.preventDefault();
    const alamat = prompt("Masukkan email akunmu:", email.value);
    if (alamat === null || !alamat.trim()) return; // Cancel / kosong
    // Pesan sengaja sama untuk semua email agar tidak membocorkan akun yang terdaftar
    alert(`Jika ${alamat.trim()} terdaftar, tautan reset kata sandi akan dikirim (simulasi).`);
  });
}

/* ---------------- REGISTER ---------------- */
function pasangDaftar(form) {
  const nama = document.getElementById("nama");
  const email = document.getElementById("email");
  const pass = document.getElementById("password");
  const konfirmasi = document.getElementById("konfirmasi");

  // keyup: cek kecocokan kata sandi sambil mengetik
  function cekSama() {
    const beda = konfirmasi.value !== "" && konfirmasi.value !== pass.value;
    konfirmasi.setCustomValidity(beda ? "Konfirmasi kata sandi tidak sama" : "");
    konfirmasi.style.boxShadow = beda ? "0 0 0 2px #c62828" : "";
  }
  pass.addEventListener("keyup", cekSama);
  konfirmasi.addEventListener("keyup", cekSama);

  // change: cek email sudah terdaftar atau belum begitu field ditinggalkan
  email.addEventListener("change", async () => {
    const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
    if (users.some((u) => u.email.toLowerCase() === email.value.trim().toLowerCase())) {
      HK.toast("Email ini sudah terdaftar", "error");
    }
  });

  // submit: simpan akun baru
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    if (pass.value !== konfirmasi.value) {
      alert("Kata sandi dan konfirmasi tidak sama!"); // ALERT BOX
      return;
    }

    const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
    if (users.some((u) => u.email.toLowerCase() === email.value.trim().toLowerCase())) {
      alert("Email sudah terdaftar. Silakan masuk.");
      return;
    }

    users.push({
      nama: nama.value.trim(),
      email: email.value.trim(),
      password: pass.value,
      telepon: "",
      alamat: "",
      foto: "",
    });

    try {
      await HK.db.simpan(HK.KEY.USERS, users);
    } catch (err) {
      alert("Gagal menyimpan akun: " + err.message);
      return;
    }

    alert(`Akun ${nama.value.trim()} berhasil dibuat. Silakan masuk.`);
    window.location.href = "login.html";
  });
}
