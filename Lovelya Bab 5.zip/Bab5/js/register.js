"use strict";
/* =====================================================
   register.js - Halaman daftar (register.html)
   Menerapkan: submit, input, alert, confirm, Web Storage.
   ===================================================== */

(function () {
  const form = document.querySelector(".login-form");
  const nama = document.getElementById("nama");
  const email = document.getElementById("email");
  const sandi = document.getElementById("password");
  const konfirmasi = document.getElementById("konfirmasi");

  /* EVENT input: validasi kecocokan kata sandi secara langsung.
     setCustomValidity() membuat browser menampilkan pesan bawaan saat submit. */
  function cekKonfirmasi() {
    konfirmasi.setCustomValidity(
      konfirmasi.value && konfirmasi.value !== sandi.value ? "Konfirmasi kata sandi tidak sama." : ""
    );
  }
  sandi.addEventListener("input", cekKonfirmasi);
  konfirmasi.addEventListener("input", cekKonfirmasi);

  /* EVENT submit: simpan akun baru ke localStorage */
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const users = ambilUsers();
    const alamatEmail = email.value.trim();

    if (users.some((u) => u.email.toLowerCase() === alamatEmail.toLowerCase())) {
      alert("Email sudah terdaftar. Silakan masuk atau gunakan email lain."); // POPUP: alert
      email.focus();
      return;
    }
    // POPUP: confirm box sebelum data disimpan
    if (!confirm(`Daftarkan akun untuk ${alamatEmail}?`)) return;

    users.push({
      nama: nama.value.trim(),
      email: alamatEmail,
      telepon: "",
      alamat: "",
      password: sandi.value,
      foto: "",
    });
    simpanUsers(users);
    tulisStorage(KUNCI.emailTerakhir, alamatEmail);
    alert("Pendaftaran berhasil! Silakan masuk.");
    location.href = "login.html";
  });
})();
