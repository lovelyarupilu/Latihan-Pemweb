/* =====================================================
   common.js  -  fungsi bersama untuk semua halaman HunianKu
   Isi:
   1. Helper Web Storage (localStorage + sessionStorage)
   2. Promise & async/await (penyimpanan dibuat asynchronous)
   3. Toast (notifikasi kecil)
   4. Guard sesi login (halaman dashboard wajib login)
   5. Event keyboard global (tombol "/" untuk fokus ke kolom cari)
   ===================================================== */
"use strict";

const HK = {};

/* ---------- Kunci penyimpanan ---------- */
HK.KEY = {
  USERS: "hk_users",         // localStorage  : daftar akun terdaftar
  KATEGORI: "hk_kategori",   // localStorage  : data kategori
  TRANSAKSI: "hk_transaksi", // localStorage  : data transaksi
  PESAN: "hk_pesan",         // localStorage  : riwayat chat
  DRAF: "hk_draf",           // localStorage  : draf pesan
  SESI: "hk_session",        // sessionStorage: email user yang sedang login
};

/* Akun demo supaya halaman login bisa langsung dicoba */
HK.USER_AWAL = [
  {
    nama: "Vey Jeanin",
    email: "Vey@gmail.com",
    password: "123456",
    telepon: "081122334455",
    alamat: "Jl.Golf 73",
    foto: "",
  },
];

/* Data awal kategori (dipakai bila localStorage masih kosong) */
HK.KATEGORI_AWAL = [
  { id: 1, nama: "Rumah", ikon: "rumah", deskripsi: "Hunian tapak dengan halaman sendiri", status: "Aktif" },
  { id: 2, nama: "Apartemen", ikon: "apartemen", deskripsi: "Hunian vertikal di pusat kota", status: "Aktif" },
  { id: 3, nama: "Kost", ikon: "kost", deskripsi: "Kamar sewa bulanan dekat kampus", status: "Aktif" },
  { id: 4, nama: "Villa", ikon: "villa", deskripsi: "Hunian liburan di area sejuk", status: "Aktif" },
];

/* ---------- 1 & 2. Web Storage + Promise ---------- */
/*
  Semua method mengembalikan Promise supaya dipakai dengan async/await.
  setTimeout kecil mensimulasikan proses asynchronous (seperti memanggil server).
*/
HK.db = {
  // Ambil data dari localStorage. Jika belum ada, simpan nilai awal.
  ambil(key, nilaiAwal) {
    return new Promise((resolve) => {
      setTimeout(() => {
        let data;
        try {
          const mentah = localStorage.getItem(key);
          data = mentah === null ? null : JSON.parse(mentah);
        } catch (err) {
          data = null; // data rusak / storage diblokir -> pakai nilai awal
        }
        if (data === null) {
          data = JSON.parse(JSON.stringify(nilaiAwal));
          try { localStorage.setItem(key, JSON.stringify(data)); } catch (e) { /* abaikan */ }
        }
        resolve(data);
      }, 60);
    });
  },

  // Simpan data ke localStorage
  simpan(key, nilai) {
    return new Promise((resolve, reject) => {
      setTimeout(() => {
        try {
          localStorage.setItem(key, JSON.stringify(nilai));
          resolve(true);
        } catch (err) {
          reject(err); // mis. kuota penuh
        }
      }, 60);
    });
  },
};

/* Jeda sederhana berbasis Promise: await HK.jeda(1000) */
HK.jeda = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

/* ---------- Sesi login (sessionStorage) ---------- */
HK.emailSesi = () => {
  try { return sessionStorage.getItem(HK.KEY.SESI); } catch (e) { return null; }
};

HK.setSesi = (email) => {
  try { sessionStorage.setItem(HK.KEY.SESI, email); } catch (e) { /* abaikan */ }
};

HK.hapusSesi = () => {
  try { sessionStorage.removeItem(HK.KEY.SESI); } catch (e) { /* abaikan */ }
};

/* Ambil objek user yang sedang login (async) */
HK.userAktif = async () => {
  const email = HK.emailSesi();
  if (!email) return null;
  const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
  return users.find((u) => u.email.toLowerCase() === email.toLowerCase()) || null;
};

/* Perbarui data user yang sedang login (async) */
HK.updateUser = async (perubahan) => {
  const email = HK.emailSesi();
  const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
  const idx = users.findIndex((u) => u.email.toLowerCase() === email.toLowerCase());
  if (idx === -1) throw new Error("User tidak ditemukan");
  users[idx] = Object.assign({}, users[idx], perubahan);
  await HK.db.simpan(HK.KEY.USERS, users);
  // Jika email diganti, sesi ikut diperbarui
  if (perubahan.email) HK.setSesi(perubahan.email);
  return users[idx];
};

/* ---------- 3. Toast ---------- */
HK.toast = (pesan, tipe = "info", durasi = 2500) => {
  let wadah = document.querySelector(".toast-container");
  if (!wadah) {
    wadah = document.createElement("div");
    wadah.className = "toast-container";
    document.body.appendChild(wadah);
  }
  const el = document.createElement("div");
  el.className = `toast toast-${tipe}`;
  el.textContent = pesan; // textContent = aman dari injeksi HTML
  wadah.appendChild(el);

  // requestAnimationFrame agar transisi CSS jalan
  requestAnimationFrame(() => el.classList.add("show"));

  setTimeout(() => {
    el.classList.remove("show");
    setTimeout(() => el.remove(), 350);
  }, durasi);
};

/* ---------- Helper umum ---------- */
HK.rupiah = (angka) => "Rp " + Number(angka || 0).toLocaleString("id-ID");

HK.hariIni = () => {
  const d = new Date();
  const p = (n) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

/* Buat elemen dengan teks (menghindari innerHTML dari input user) */
HK.el = (tag, opsi = {}, teks = "") => {
  const e = document.createElement(tag);
  if (opsi.kelas) e.className = opsi.kelas;
  if (opsi.attr) Object.keys(opsi.attr).forEach((k) => e.setAttribute(k, opsi.attr[k]));
  if (teks !== "") e.textContent = teks;
  return e;
};

/* Jalankan fungsi setelah DOM siap */
HK.siap = (fn) => {
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", fn);
  else fn();
};

/* ---------- 4. Guard sesi ---------- */
/*
  Halaman dashboard (yang punya .dash) hanya boleh dibuka setelah login.
  Jika belum login -> popup alert lalu pindah ke login.html
*/
HK.guard = () => {
  const halamanDash = document.querySelector(".dash");
  if (halamanDash && !HK.emailSesi()) {
    alert("Silakan masuk terlebih dahulu untuk membuka halaman ini.");
    window.location.href = "login.html";
    return false;
  }
  return true;
};

/* Tampilkan foto profil user di header (jika sudah pernah diubah) */
HK.pasangAvatar = async () => {
  const gambar = document.querySelectorAll("img.dash-avatar-img, img.profil-photo-img");
  if (!gambar.length) return;
  const user = await HK.userAktif();
  if (user && user.foto) gambar.forEach((g) => (g.src = user.foto));
};

/* ---------- 5. Event keyboard global ---------- */
HK.siap(() => {
  if (!HK.guard()) return;
  HK.pasangAvatar();

  // keydown: tekan "/" untuk langsung fokus ke kolom cari
  document.addEventListener("keydown", (e) => {
    const sedangMengetik = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement.tagName);
    if (e.key === "/" && !sedangMengetik) {
      const cari = document.querySelector(".dash-search input");
      if (cari) {
        e.preventDefault();
        cari.focus();
      }
    }
  });

  // keydown Escape pada kolom cari: kosongkan dan tampilkan semua lagi
  const kolomCari = document.querySelector(".dash-search input");
  if (kolomCari) {
    kolomCari.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        kolomCari.value = "";
        kolomCari.dispatchEvent(new Event("input")); // picu pencarian ulang
        kolomCari.blur();
      }
    });
  }
});
