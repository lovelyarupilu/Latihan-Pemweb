/* =====================================================
   kategori-entry.js  -  Form Entry Kategori (katagoriEntry.html)
   - PopUp: alert (validasi), confirm (kembali tanpa simpan)
   - Event: input, change, submit, reset, click
   - Web Storage + Promise + async/await
   Memakai HK.KATEGORI_AWAL dari common.js.
   ===================================================== */
"use strict";

HK.siap(() => {
  const form = document.getElementById("form-entry-kategori");
  if (!form) return;

  const nama = document.getElementById("nama");
  const ikon = document.getElementById("ikon");
  const deskripsi = document.getElementById("deskripsi");
  const prevSvg = document.querySelector(".entry-preview-box svg path");
  const prevNama = document.querySelector(".entry-preview-box span");
  const btnKembali = form.querySelector("a.btn");

  /* Bentuk ikon untuk pratinjau (sama dengan ikon di Beranda) */
  const IKON = {
    rumah: "M12 3 2 12h3v9h5v-6h4v6h5v-9h3z",
    apartemen: "M3 21V9h7v12zm8 0V3h10v18zM5 11v2h3v-2zm0 4v2h3v-2zm8-9v2h2V6zm4 0v2h2V6zm-4 4v2h2v-2zm4 0v2h2v-2zm-4 4v2h2v-2zm4 0v2h2v-2z",
    kost: "M12 3 2 12h3v9h14v-9h3zm0 7a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm-1 5h2v4h-2z",
    villa: "M12 3 2 12h3v9h14v-9h3zm-2 7 6 3.500-6 3.500z",
  };

  let sudahDiubah = false; // dipakai untuk konfirmasi saat klik Kembali

  /* Pratinjau diperbarui real-time */
  function perbaruiPratinjau() {
    prevNama.textContent = nama.value.trim() || "Kategori";
    prevSvg.setAttribute("d", IKON[ikon.value] || IKON.rumah);
  }

  // input: tiap ketikan memperbarui nama pratinjau
  nama.addEventListener("input", () => {
    sudahDiubah = true;
    perbaruiPratinjau();
  });
  deskripsi.addEventListener("input", () => (sudahDiubah = true));

  // change: ganti ikon -> pratinjau ikut berubah
  ikon.addEventListener("change", () => {
    sudahDiubah = true;
    perbaruiPratinjau();
  });

  // reset: kembalikan pratinjau (setTimeout 0 menunggu form benar-benar direset)
  form.addEventListener("reset", () => {
    sudahDiubah = false;
    setTimeout(perbaruiPratinjau, 0);
  });

  // click Kembali: CONFIRM BOX jika ada data yang belum disimpan
  btnKembali.addEventListener("click", (e) => {
    if (sudahDiubah && !confirm("Data belum disimpan. Yakin ingin kembali?")) {
      e.preventDefault();
    }
  });

  // submit: validasi lalu simpan ke localStorage
  form.addEventListener("submit", async (e) => {
    e.preventDefault();

    const nm = nama.value.trim();
    if (!nm) {
      alert("Nama kategori wajib diisi.");
      nama.focus();
      return;
    }

    const data = await HK.db.ambil(HK.KEY.KATEGORI, HK.KATEGORI_AWAL);
    if (data.some((k) => k.nama.toLowerCase() === nm.toLowerCase())) {
      alert(`Kategori "${nm}" sudah ada.`);
      nama.focus();
      return;
    }

    data.push({
      id: Date.now(),
      nama: nm,
      ikon: ikon.value,
      deskripsi: deskripsi.value.trim(),
      status: form.elements["status"].value, // radio Aktif/Nonaktif
    });

    try {
      await HK.db.simpan(HK.KEY.KATEGORI, data);
    } catch (err) {
      alert("Gagal menyimpan: " + err.message);
      return;
    }

    sudahDiubah = false;
    HK.toast(`Kategori "${nm}" berhasil disimpan`, "success");
    await HK.jeda(900);
    window.location.href = "katagori.html";
  });
});
