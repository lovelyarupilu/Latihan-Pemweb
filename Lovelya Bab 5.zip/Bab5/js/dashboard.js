/* =====================================================
   dashboard.js  -  Halaman Beranda
   - Event: submit, input (pencarian langsung), click, mouseover/mouseout
   - Web Storage: sessionStorage (toast sambutan 1x), localStorage (terakhir dilihat)
   - async/await
   ===================================================== */
"use strict";

HK.siap(async () => {
  if (!HK.emailSesi()) return; // guard di common.js sudah mengalihkan halaman

  const form = document.querySelector(".dash-search");
  const kolom = form.querySelector("input");
  const kartu = document.querySelectorAll(".dash-card");
  const grid = document.querySelector(".dash-grid");
  const judulTerbaru = document.querySelector("h2.dash-subtitle");

  /* Pesan "tidak ditemukan" dibuat sekali lalu disembunyikan */
  const kosong = HK.el("p", {}, "Hunian tidak ditemukan.");
  kosong.style.cssText = "font-size:12px;color:#777;margin:8px 0;";
  kosong.hidden = true;
  grid.after(kosong);

  /* Pencarian: dipanggil saat submit maupun saat mengetik (event input) */
  function cari() {
    const kata = kolom.value.trim().toLowerCase();
    let ada = 0;
    kartu.forEach((k) => {
      const cocok = k.querySelector(".dash-card-name").textContent.toLowerCase().includes(kata);
      k.style.display = cocok ? "" : "none";
      if (cocok) ada++;
    });
    kosong.hidden = ada > 0;
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();
    cari();
  });
  kolom.addEventListener("input", cari);

  /* Hunian terakhir dilihat -> localStorage */
  const KUNCI = "hk_terakhir_dilihat";
  const terakhir = localStorage.getItem(KUNCI);
  if (terakhir) {
    const info = HK.el("p", {}, `Terakhir kamu lihat: ${terakhir}`);
    info.style.cssText = "font-size:11px;color:#1f3a93;margin-bottom:8px;font-weight:700;";
    judulTerbaru.after(info);
  }

  kartu.forEach((k) => {
    const nama = k.querySelector(".dash-card-name").textContent;

    // click: simpan nama hunian yang diklik sebelum pindah ke halaman Pesan
    k.addEventListener("click", () => localStorage.setItem(KUNCI, nama));

    // mouseover / mouseout: kartu sedikit membesar saat disorot
    k.addEventListener("mouseover", () => (k.style.transform = "translateY(-3px)"));
    k.addEventListener("mouseout", () => (k.style.transform = ""));
  });

  /* Toast sambutan, hanya sekali per sesi (sessionStorage) */
  const user = await HK.userAktif();
  if (user && !sessionStorage.getItem("hk_sambutan")) {
    sessionStorage.setItem("hk_sambutan", "1");
    HK.toast(`Halo ${user.nama.split(" ")[0]}, selamat datang kembali!`, "success");
  }
});
