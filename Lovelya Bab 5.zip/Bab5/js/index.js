/* =====================================================
   index.js  -  Halaman utama (landing page)
   Fitur:
   - PopUp: prompt (nama pengunjung), confirm (Lihat Semua), alert (detail hunian)
   - Event: load, submit, change, click, dblclick, mouseover, mouseout
   - Web Storage: nama pengunjung disimpan di localStorage
   - fetch + async/await: memuat hunian tambahan dari data/hunian.json
   ===================================================== */
"use strict";

(function () {
  const sapaan = document.getElementById("sapaan");
  const form = document.getElementById("formCari");
  const daftar = document.getElementById("daftarHunian");
  const hasil = document.getElementById("hasilCari");
  const btnLihat = document.getElementById("btnLihat");
  const KUNCI_NAMA = "hk_pengunjung";

  /* ---------- Data tambahan pada kartu bawaan HTML ---------- */
  // Kartu bawaan diberi atribut data-* supaya bisa difilter
  const dataBawaan = [
    { kota: "Bandung", tipe: "Rumah", harga: 30000000000, perumahan: "Cluster A" },
    { kota: "Bogor", tipe: "Rumah", harga: 35000000000, perumahan: "Cluster B" },
  ];
  daftar.querySelectorAll(".card").forEach((kartu, i) => {
    const d = dataBawaan[i];
    if (!d) return;
    kartu.dataset.kota = d.kota;
    kartu.dataset.tipe = d.tipe;
    kartu.dataset.harga = d.harga;
    kartu.dataset.perumahan = d.perumahan;
  });

  /* ---------- Buat kartu hunian dari data (DOM) ---------- */
  function buatKartu(h) {
    const kartu = HK.el("article", { kelas: "card" });
    kartu.dataset.kota = h.kota;
    kartu.dataset.tipe = h.tipe;
    kartu.dataset.harga = h.harga;
    kartu.dataset.perumahan = h.perumahan;

    const img = HK.el("img", { attr: { src: h.gambar, alt: h.nama } });
    const nama = HK.el("h3", { kelas: "card-name" }, h.nama);
    const info = HK.el("div", { kelas: "card-info" });
    info.appendChild(HK.el("span", { kelas: "card-city" }, h.kota));
    info.appendChild(HK.el("span", { kelas: "card-price" }, HK.rupiah(h.harga)));

    kartu.append(img, nama, info);
    pasangEventKartu(kartu);
    return kartu;
  }

  /* ---------- Event pada kartu ---------- */
  function pasangEventKartu(kartu) {
    // click: tandai kartu yang dipilih (toggle kelas CSS .dipilih)
    kartu.addEventListener("click", () => kartu.classList.toggle("dipilih"));

    // dblclick: tampilkan detail dengan ALERT BOX
    kartu.addEventListener("dblclick", () => {
      const nama = kartu.querySelector(".card-name").textContent;
      alert(
        `${nama}\n` +
          `Lokasi     : ${kartu.dataset.kota}\n` +
          `Tipe       : ${kartu.dataset.tipe}\n` +
          `Perumahan  : ${kartu.dataset.perumahan}\n` +
          `Harga      : ${HK.rupiah(kartu.dataset.harga)}`
      );
    });

    // mouseover / mouseout: efek sorot saat mouse di atas kartu
    kartu.addEventListener("mouseover", () => (kartu.style.opacity = "0.85"));
    kartu.addEventListener("mouseout", () => (kartu.style.opacity = "1"));
  }

  daftar.querySelectorAll(".card").forEach(pasangEventKartu);

  /* ---------- Filter pencarian ---------- */
  function cocokHarga(harga, indeksPilihan) {
    // indeksPilihan: 1 = < 500 juta, 2 = 500 juta - 1 M, 3 = > 1 M
    if (indeksPilihan === 1) return harga < 500000000;
    if (indeksPilihan === 2) return harga >= 500000000 && harga <= 1000000000;
    if (indeksPilihan === 3) return harga > 1000000000;
    return true;
  }

  function jalankanFilter() {
    const lokasi = form.lokasi.value;
    const tipe = form.tipe.value;
    const perumahan = form.perumahan.value;
    const idxHarga = form.harga.selectedIndex;

    let tampil = 0;
    daftar.querySelectorAll(".card").forEach((kartu) => {
      const ok =
        (!lokasi || kartu.dataset.kota === lokasi) &&
        (!tipe || kartu.dataset.tipe === tipe) &&
        (!perumahan || kartu.dataset.perumahan === perumahan) &&
        cocokHarga(Number(kartu.dataset.harga), idxHarga);
      kartu.style.display = ok ? "" : "none";
      if (ok) tampil++;
    });

    const adaFilter = lokasi || tipe || perumahan || idxHarga > 0;
    hasil.classList.toggle("tampil", Boolean(adaFilter));
    hasil.textContent = tampil
      ? `Ditemukan ${tampil} hunian sesuai pencarianmu`
      : "Maaf, belum ada hunian yang cocok. Coba ubah filter.";
  }

  // submit: tombol "Cari Hunian"
  form.addEventListener("submit", (e) => {
    e.preventDefault(); // cegah reload halaman
    jalankanFilter();
  });

  // change: hasil langsung diperbarui saat pilihan dropdown berubah
  form.querySelectorAll("select").forEach((s) => s.addEventListener("change", jalankanFilter));

  /* ---------- Tombol Lihat Semua: CONFIRM BOX ---------- */
  btnLihat.addEventListener("click", (e) => {
    if (HK.emailSesi()) {
      e.preventDefault();
      window.location.href = "dashboard.html"; // sudah login
      return;
    }
    const lanjut = confirm("Untuk melihat semua hunian kamu perlu masuk dulu.\nLanjut ke halaman masuk?");
    if (!lanjut) e.preventDefault(); // Cancel -> tetap di halaman ini
  });

  /* ---------- fetch + async/await ---------- */
  // Ambil hunian tambahan dari file JSON.
  // Catatan: fetch ke file lokal hanya jalan lewat web server (Laragon/MAMP),
  // jika dibuka langsung (file://) akan gagal dan ditangani oleh catch.
  async function muatHunianTambahan() {
    try {
      const respon = await fetch("data/hunian.json");
      if (!respon.ok) throw new Error("HTTP " + respon.status);
      const data = await respon.json();
      data.forEach((h) => daftar.appendChild(buatKartu(h)));
    } catch (err) {
      console.info("Hunian tambahan tidak dimuat:", err.message);
    }
  }

  /* ---------- Event load + PROMPT BOX ---------- */
  window.addEventListener("load", async () => {
    await muatHunianTambahan();

    // Nama pengunjung disimpan di localStorage agar tidak ditanya terus
    let nama = null;
    try { nama = localStorage.getItem(KUNCI_NAMA); } catch (e) { /* abaikan */ }

    if (!nama && !sessionStorage.getItem("hk_sudah_ditanya")) {
      sessionStorage.setItem("hk_sudah_ditanya", "1"); // tanya 1x per sesi
      const jawab = prompt("Halo! Siapa namamu?", "Teman");
      if (jawab && jawab.trim()) {
        nama = jawab.trim();
        try { localStorage.setItem(KUNCI_NAMA, nama); } catch (e) { /* abaikan */ }
      }
    }

    if (nama) {
      sapaan.textContent = `Halo ${nama}, ini rekomendasi hunian sebagai referensimu`;
      HK.toast(`Selamat datang, ${nama}!`, "success");
    }
  });
})();
