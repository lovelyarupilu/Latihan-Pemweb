"use strict";
/* =====================================================
   kategoriEntry.js - Tambah kategori (katagoriEntry.html)
   Menerapkan: submit, input, change, reset, alert, Web Storage.
   ===================================================== */

// Path ikon SVG sama seperti yang dipakai di dashboard.html
const IKON_KATEGORI = {
  rumah: "M12 3 2 12h3v9h5v-6h4v6h5v-9h3z",
  apartemen: "M3 21V9h7v12zm8 0V3h10v18zM5 11v2h3v-2zm0 4v2h3v-2zm8-9v2h2V6zm4 0v2h2V6zm-4 4v2h2v-2zm4 0v2h2v-2zm-4 4v2h2v-2zm4 0v2h2v-2z",
  kost: "M12 3 2 12h3v9h14v-9h3zm0 7a2 2 0 1 1 0 4 2 2 0 0 1 0-4zm-1 5h2v4h-2z",
  villa: "M12 3 2 12h3v9h14v-9h3zm-2 7 6 3.500-6 3.500z",
};

function mulaiEntryKategori() {
  const form = document.getElementById("form-entry-kategori");
  const nama = document.getElementById("nama");
  const ikon = document.getElementById("ikon");
  const deskripsi = document.getElementById("deskripsi");
  const hintNama = nama.parentElement.querySelector(".form-hint");
  const hintDeskripsi = deskripsi.parentElement.querySelector(".form-hint");
  const pratinjauNama = document.querySelector(".entry-preview-box .dash-cat span");
  const pratinjauIkon = document.querySelector(".entry-preview-box .dash-cat path");

  /* Perbarui pratinjau & penghitung karakter */
  function segarkan() {
    pratinjauNama.textContent = nama.value.trim() || "Kategori";
    pratinjauIkon.setAttribute("d", IKON_KATEGORI[ikon.value]);
    hintNama.textContent = `${nama.value.length}/50 karakter.`;
    hintDeskripsi.textContent = `${deskripsi.value.length}/150 karakter.`;
  }

  /* EVENT input & change: pratinjau langsung berubah saat mengetik / memilih ikon */
  nama.addEventListener("input", segarkan);
  deskripsi.addEventListener("input", segarkan);
  ikon.addEventListener("change", segarkan);

  /* EVENT reset: setelah form dikosongkan, pratinjau ikut dikembalikan */
  form.addEventListener("reset", () => setTimeout(segarkan, 0));

  /* EVENT submit: simpan ke localStorage */
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const namaBersih = nama.value.trim();
    const data = ambilKategori();

    if (data.some((k) => k.nama.toLowerCase() === namaBersih.toLowerCase())) {
      alert(`Kategori "${namaBersih}" sudah ada.`); // POPUP: alert
      nama.focus();
      return;
    }
    data.push({
      id: idBerikutnya(data),
      nama: namaBersih,
      ikon: ikon.value,
      deskripsi: deskripsi.value.trim(),
      status: form.elements["status"].value,
    });
    simpanKategori(data);
    alert("Kategori berhasil disimpan."); // POPUP: alert
    location.href = "katagori.html";
  });

  segarkan();
}

if (!HALAMAN_DITOLAK) mulaiEntryKategori();
