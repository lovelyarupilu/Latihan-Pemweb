/* =====================================================
   profil.js  -  Halaman Profil
   - PopUp: prompt (edit data / ganti sandi), confirm (keluar, simpan), alert
   - Event: click, change (pilih foto), load (FileReader)
   - Web Storage: data user di localStorage, sesi di sessionStorage
   - Promise + async/await
   ===================================================== */
"use strict";

HK.siap(async () => {
  const daftarNilai = document.querySelectorAll(".profil-value");
  if (!daftarNilai.length) return;

  let user = await HK.userAktif();
  if (!user) return; // guard di common.js sudah mengalihkan

  /* Definisi field yang bisa diedit (urutan sama dengan baris di HTML) */
  const FIELD = [
    { kunci: "nama", label: "Nama Lengkap", cek: (v) => v.length >= 3 && v.length <= 60, galat: "Nama 3-60 karakter." },
    { kunci: "email", label: "Email", cek: (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), galat: "Format email tidak valid." },
    { kunci: "telepon", label: "Nomor Telepon", cek: (v) => /^[0-9+]{8,15}$/.test(v), galat: "Nomor telepon 8-15 digit angka." },
    { kunci: "alamat", label: "Alamat", cek: (v) => v.length >= 3 && v.length <= 120, galat: "Alamat 3-120 karakter." },
  ];

  const namaPendek = document.querySelector(".profil-name");

  function tampilkan() {
    FIELD.forEach((f, i) => (daftarNilai[i].textContent = user[f.kunci] || "-"));
    namaPendek.textContent = user.nama.split(" ")[0];
  }

  /* Tanya satu field lewat PROMPT BOX. Mengembalikan true jika berhasil diubah */
  async function editField(f) {
    const jawab = prompt(`${f.label}:`, user[f.kunci]);
    if (jawab === null) return false; // Cancel
    const nilai = jawab.trim();
    if (!f.cek(nilai)) {
      alert(f.galat);
      return false;
    }
    if (f.kunci === "email" && nilai.toLowerCase() !== user.email.toLowerCase()) {
      const users = await HK.db.ambil(HK.KEY.USERS, HK.USER_AWAL);
      if (users.some((u) => u.email.toLowerCase() === nilai.toLowerCase())) {
        alert("Email itu sudah dipakai akun lain.");
        return false;
      }
    }
    user = await HK.updateUser({ [f.kunci]: nilai });
    return true;
  }

  /* click ikon pensil/email/telepon/alamat: edit satu field */
  document.querySelectorAll(".profil-row").forEach((row, i) => {
    row.querySelector(".profil-icon").style.cursor = "pointer";
    row.querySelector(".profil-icon").addEventListener("click", async () => {
      if (await editField(FIELD[i])) {
        tampilkan();
        HK.toast(`${FIELD[i].label} diperbarui`, "success");
      }
    });
  });

  const [btnEdit, btnSandi] = document.querySelectorAll(".profil-actions .btn-dark");

  /* click Edit Profil: tanya semua field berurutan */
  btnEdit.addEventListener("click", async (e) => {
    e.preventDefault();
    for (const f of FIELD) {
      const lanjut = await editField(f);
      if (!lanjut && !confirm("Lanjut mengedit data berikutnya?")) break; // CONFIRM BOX
    }
    tampilkan();
  });

  /* click Ubah Kata Sandi */
  btnSandi.addEventListener("click", async (e) => {
    e.preventDefault();
    const lama = prompt("Masukkan kata sandi lama:");
    if (lama === null) return;
    if (lama !== user.password) {
      alert("Kata sandi lama salah.");
      return;
    }
    const baru = prompt("Masukkan kata sandi baru (minimal 6 karakter):");
    if (baru === null) return;
    if (baru.length < 6) {
      alert("Kata sandi baru minimal 6 karakter.");
      return;
    }
    user = await HK.updateUser({ password: baru });
    HK.toast("Kata sandi berhasil diubah", "success");
  });

  /* click Keluar: CONFIRM BOX, lalu hapus sesi */
  document.querySelector(".profil-logout").addEventListener("click", (e) => {
    if (!confirm("Yakin ingin keluar dari akunmu?")) {
      e.preventDefault(); // Cancel -> tetap di halaman
      return;
    }
    HK.hapusSesi();
    sessionStorage.removeItem("hk_sambutan");
  });

  /* Ubah Foto: input file tersembunyi + FileReader (event change & load) */
  const inputFoto = document.createElement("input");
  inputFoto.type = "file";
  inputFoto.accept = "image/*";
  inputFoto.hidden = true;
  document.body.appendChild(inputFoto);

  document.querySelector(".profil-photo-btn").addEventListener("click", () => inputFoto.click());

  inputFoto.addEventListener("change", () => {
    const file = inputFoto.files[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      alert("File harus berupa gambar.");
      return;
    }
    if (file.size > 300 * 1024) {
      alert("Ukuran foto maksimal 300 KB (localStorage terbatas).");
      return;
    }
    const baca = new FileReader();
    baca.addEventListener("load", async () => {
      try {
        user = await HK.updateUser({ foto: baca.result });
        document.querySelectorAll("img.dash-avatar-img, img.profil-photo-img").forEach((g) => (g.src = user.foto));
        HK.toast("Foto profil diperbarui", "success");
      } catch (err) {
        alert("Gagal menyimpan foto: " + err.message);
      }
    });
    baca.readAsDataURL(file);
  });

  tampilkan();
});
