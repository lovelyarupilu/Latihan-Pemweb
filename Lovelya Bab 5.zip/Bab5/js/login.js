"use strict";
/* =====================================================
   login.js - Halaman masuk (login.html)
   Menerapkan: submit, keyup/keydown, click, load,
   alert, prompt, Web Storage.
   ===================================================== */

(function () {
  const form = document.querySelector(".login-form");
  const inputEmail = document.getElementById("email");
  const inputSandi = document.getElementById("password");
  const kotakError = document.getElementById("login-error");
  const linkLupa = document.querySelector(".forgot");

  function tampilkanError(teks) {
    kotakError.textContent = teks;
    kotakError.hidden = false;
  }

  /* EVENT load: isi otomatis email terakhir yang berhasil login (Web Storage) */
  window.addEventListener("load", () => {
    const terakhir = bacaStorage(KUNCI.emailTerakhir, "");
    if (terakhir) {
      inputEmail.value = terakhir;
      inputSandi.focus();
    }
  });

  /* EVENT input: sembunyikan pesan error begitu pengguna mulai mengetik lagi */
  [inputEmail, inputSandi].forEach((el) =>
    el.addEventListener("input", () => (kotakError.hidden = true))
  );

  /* EVENT keyup: peringatan Caps Lock aktif pada kolom kata sandi */
  const peringatan = document.createElement("small");
  peringatan.style.cssText = "display:none;color:#c0392b;font-size:11px;margin-top:4px";
  peringatan.textContent = "Caps Lock sedang aktif";
  inputSandi.insertAdjacentElement("afterend", peringatan);

  function cekCapsLock(e) {
    if (e.getModifierState) {
      peringatan.style.display = e.getModifierState("CapsLock") ? "block" : "none";
    }
  }
  inputSandi.addEventListener("keyup", cekCapsLock);
  inputSandi.addEventListener("keydown", cekCapsLock);
  inputSandi.addEventListener("blur", () => (peringatan.style.display = "none"));

  /* EVENT submit: proses login */
  form.addEventListener("submit", (e) => {
    e.preventDefault();
    const email = inputEmail.value.trim().toLowerCase();
    const sandi = inputSandi.value;

    const user = ambilUsers().find((u) => u.email.toLowerCase() === email && u.password === sandi);
    if (!user) {
      tampilkanError("Email atau kata sandi salah.");
      alert("Login gagal: email atau kata sandi tidak cocok."); // POPUP: alert
      inputSandi.select();
      return;
    }

    masukkanSesi(user.email);                       // sessionStorage: hilang saat tab ditutup
    tulisStorage(KUNCI.emailTerakhir, user.email);  // localStorage : diingat terus
    alert(`Selamat datang, ${user.nama}!`);         // POPUP: alert
    location.href = "dashboard.html";
  });

  /* EVENT click + POPUP prompt: Lupa Kata Sandi */
  linkLupa.addEventListener("click", (e) => {
    e.preventDefault();
    const email = prompt("Masukkan email akun Anda:", inputEmail.value); // POPUP: prompt
    if (email === null) return; // pengguna menekan Cancel
    const ada = ambilUsers().some((u) => u.email.toLowerCase() === email.trim().toLowerCase());
    if (ada) {
      tampilkanToast("Tautan reset kata sandi dikirim ke email Anda (simulasi).", "success");
    } else {
      tampilkanToast("Email tidak terdaftar.", "error");
    }
  });
})();
