/* =====================================================
   kategori.js  -  Daftar Kategori (katagori.html)
   - PopUp: confirm (hapus), prompt (edit), alert (validasi)
   - Event: click (delegasi), input (cari)
   - Web Storage: data di localStorage
   - Promise + async/await
   ===================================================== */
"use strict";


if (document.getElementById("tabel-kategori")) {
  HK.siap(async () => {
    const tbody = document.getElementById("tabel-kategori");
    const cari = document.getElementById("cari");
    const ringkasan = document.getElementById("ringkasan");

    let data = await HK.db.ambil(HK.KEY.KATEGORI, HK.KATEGORI_AWAL);

    /* Simpan + tampilkan ulang, dengan penanganan error */
    async function simpan() {
      try {
        await HK.db.simpan(HK.KEY.KATEGORI, data);
      } catch (err) {
        alert("Gagal menyimpan data: " + err.message);
      }
    }

    function render() {
      const kata = cari.value.trim().toLowerCase();
      const tampil = data.filter(
        (k) => k.nama.toLowerCase().includes(kata) || k.deskripsi.toLowerCase().includes(kata)
      );

      tbody.replaceChildren(); // kosongkan tabel

      if (!tampil.length) {
        const tr = HK.el("tr");
        const td = HK.el("td", { kelas: "table-empty", attr: { colspan: "4" } }, "Data tidak ditemukan");
        tr.appendChild(td);
        tbody.appendChild(tr);
      }

      tampil.forEach((k, i) => {
        const tr = HK.el("tr");
        tr.appendChild(HK.el("td", {}, String(i + 1)));

        const tdNama = HK.el("td", {}, k.nama + " ");
        if (k.status === "Nonaktif") tdNama.appendChild(HK.el("span", { kelas: "badge badge-batal" }, "Nonaktif"));
        tr.appendChild(tdNama);

        tr.appendChild(HK.el("td", {}, k.deskripsi || "-"));

        const tdAksi = HK.el("td");
        const aksi = HK.el("div", { kelas: "table-actions" });
        const btnEdit = HK.el("button", { kelas: "btn btn-light btn-sm", attr: { type: "button", "data-aksi": "edit", "data-id": k.id } }, "Edit");
        const btnHapus = HK.el("button", { kelas: "btn btn-danger btn-sm", attr: { type: "button", "data-aksi": "hapus", "data-id": k.id } }, "Hapus");
        aksi.append(btnEdit, btnHapus);
        tdAksi.appendChild(aksi);
        tr.appendChild(tdAksi);

        tbody.appendChild(tr);
      });

      ringkasan.textContent = `Total ${data.length} kategori, ${data.filter((k) => k.status === "Aktif").length} aktif`;
    }

    /* Event delegation: satu listener untuk semua tombol di tabel */
    tbody.addEventListener("click", async (e) => {
      const btn = e.target.closest("button[data-aksi]");
      if (!btn) return;
      const id = Number(btn.dataset.id);
      const item = data.find((k) => k.id === id);
      if (!item) return;

      if (btn.dataset.aksi === "hapus") {
        // CONFIRM BOX
        if (confirm(`Hapus kategori "${item.nama}"?`)) {
          data = data.filter((k) => k.id !== id);
          await simpan();
          render();
          HK.toast("Kategori dihapus", "info");
        }
      }

      if (btn.dataset.aksi === "edit") {
        // PROMPT BOX (nilai default = data lama)
        const namaBaru = prompt("Nama kategori:", item.nama);
        if (namaBaru === null) return; // Cancel
        const nm = namaBaru.trim();
        if (!nm || nm.length > 50) {
          alert("Nama wajib diisi dan maksimal 50 karakter.");
          return;
        }
        if (data.some((k) => k.id !== id && k.nama.toLowerCase() === nm.toLowerCase())) {
          alert(`Kategori "${nm}" sudah ada.`);
          return;
        }
        const desBaru = prompt("Deskripsi kategori:", item.deskripsi);
        if (desBaru === null) return;

        item.nama = nm;
        item.deskripsi = desBaru.trim().slice(0, 150);
        await simpan();
        render();
        HK.toast("Kategori diperbarui", "success");
      }
    });

    // input: pencarian langsung saat mengetik
    cari.addEventListener("input", render);

    render();
  });
}
