/* =====================================================
   pesan.js  -  Halaman Pesan (chat dengan admin hunian)
   - PopUp: confirm (buang draf pesan), alert (gagal simpan)
   - Event: click (tab & percakapan), submit, input (simpan draf), keydown
   - Web Storage: riwayat chat + draf di localStorage
   - Promise + async/await: balasan otomatis admin setelah jeda
   ===================================================== */
"use strict";

HK.siap(async () => {
  const daftar = document.querySelector(".pesan-list");
  if (!daftar) return;

  const itemList = [...daftar.querySelectorAll(".pesan-item")];
  const tabs = document.querySelectorAll(".pesan-tab");
  const bubbles = document.querySelector(".pesan-bubbles");
  const form = document.querySelector(".pesan-input");
  const input = form.querySelector("input");
  const tandaCek = document.querySelector(".pesan-check");      // ikon centang percakapan aktif
  const tandaBaca = document.querySelector(".bubble-read").cloneNode(true); // ikon "terbaca" pada bubble keluar

  /* Percakapan: id diambil dari urutan item di HTML */
  const KONV = ["modern", "kost"];
  itemList.forEach((it, i) => (it.dataset.id = KONV[i] || "k" + i));
  const teksAdmin = itemList.map((it) => it.querySelector("span").textContent); // simpan teks asli

  const PESAN_AWAL = {
    modern: [],
    kost: [
      { dari: "saya", teks: "Halo, Apakah kost dekat kampus masih tersedia kamar kosong?" },
      { dari: "admin", teks: "Halo, Masih Tersedia kak, apakah mau survey terlebih dahulu?" },
    ],
  };

  let riwayat = await HK.db.ambil(HK.KEY.PESAN, PESAN_AWAL);
  let draf = await HK.db.ambil(HK.KEY.DRAF, {});
  let aktif = "kost";
  let modeDraf = false;

  /* ---------- Tampilkan chat ---------- */
  function renderChat() {
    bubbles.replaceChildren();
    (riwayat[aktif] || []).forEach((p) => tambahBubble(p, false));
    bubbles.scrollTop = bubbles.scrollHeight;
    input.value = draf[aktif] || "";
  }

  function tambahBubble(p, gulir = true) {
    const b = HK.el("div", { kelas: "bubble " + (p.dari === "saya" ? "bubble-out" : "bubble-in") });
    b.appendChild(HK.el("p", {}, p.teks));
    if (p.dari === "saya") b.appendChild(tandaBaca.cloneNode(true));
    bubbles.appendChild(b);
    if (gulir) bubbles.scrollTop = bubbles.scrollHeight;
  }

  /* ---------- Daftar percakapan / tab ---------- */
  function renderList() {
    // hapus pesan kosong lama (jika ada)
    daftar.querySelectorAll(".pesan-kosong").forEach((n) => n.remove());

    let terlihat = 0;
    itemList.forEach((it, i) => {
      const id = it.dataset.id;
      const adaDraf = Boolean(draf[id]);
      const tampil = !modeDraf || adaDraf;
      it.parentElement.hidden = !tampil;
      if (tampil) terlihat++;
      it.querySelector("span").textContent = modeDraf && adaDraf ? "Draf: " + draf[id] : teksAdmin[i];
      it.classList.toggle("active", id === aktif);
      if (id === aktif && tandaCek) it.appendChild(tandaCek);
    });

    if (!terlihat) {
      const li = HK.el("li", { kelas: "pesan-kosong" }, "Belum ada draf pesan.");
      li.style.cssText = "font-size:10px;color:#777;padding:8px;";
      daftar.appendChild(li);
    }
  }

  // click: pindah percakapan
  itemList.forEach((it) =>
    it.addEventListener("click", (e) => {
      e.preventDefault();
      aktif = it.dataset.id;
      renderList();
      renderChat();
    })
  );

  // click: tab Pesan Masuk / Draf Pesan
  tabs.forEach((tab, i) =>
    tab.addEventListener("click", () => {
      tabs.forEach((t) => t.classList.remove("active"));
      tab.classList.add("active");
      modeDraf = i === 1;
      renderList();
    })
  );

  /* ---------- Draf: disimpan otomatis tiap mengetik (event input) ---------- */
  input.addEventListener("input", () => {
    if (input.value.trim()) draf[aktif] = input.value;
    else delete draf[aktif];
    HK.db.simpan(HK.KEY.DRAF, draf).catch(() => {});
    if (modeDraf) renderList();
  });

  // keydown: tekan Escape untuk membuang draf percakapan ini
  input.addEventListener("keydown", (e) => {
    if (e.key === "Escape" && input.value) {
      if (confirm("Buang draf pesan ini?")) {          // CONFIRM BOX
        input.value = "";
        input.dispatchEvent(new Event("input"));
      }
    }
  });

  /* ---------- Balasan otomatis admin (Promise + async/await) ---------- */
  function buatBalasan(teks) {
    const t = teks.toLowerCase();
    if (t.includes("survey")) return "Baik kak, survey bisa dijadwalkan setiap hari pukul 09.00-16.00.";
    if (t.includes("harga") || t.includes("biaya")) return "Untuk harga lengkap akan kami kirimkan lewat brosur ya kak.";
    if (t.includes("terima kasih") || t.includes("makasih")) return "Sama-sama kak, kami siap membantu!";
    return "Terima kasih kak, pesanmu sudah kami terima. Admin akan membalas sebentar lagi.";
  }

  async function balas(id, teksUser) {
    await HK.jeda(1200); // admin seolah sedang mengetik
    const balasan = { dari: "admin", teks: buatBalasan(teksUser) };
    riwayat[id].push(balasan);
    await HK.db.simpan(HK.KEY.PESAN, riwayat);
    if (id === aktif) tambahBubble(balasan);
    else HK.toast("Pesan baru dari admin", "info");
  }

  // submit: kirim pesan
  form.addEventListener("submit", async (e) => {
    e.preventDefault();
    const teks = input.value.trim();
    if (!teks) return;

    const id = aktif;
    const p = { dari: "saya", teks };
    riwayat[id] = riwayat[id] || [];
    riwayat[id].push(p);
    tambahBubble(p);

    input.value = "";
    delete draf[id];
    try {
      await HK.db.simpan(HK.KEY.PESAN, riwayat);
      await HK.db.simpan(HK.KEY.DRAF, draf);
    } catch (err) {
      alert("Pesan gagal disimpan: " + err.message);
    }
    renderList();
    balas(id, teks);
  });

  renderList();
  renderChat();
});
