<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Transaksi - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <img class="dash-avatar dash-avatar-img" src="images/profil.jpg" alt="Foto profil">
      </a>
    </header>

    <div class="dash-body">

      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link active"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <main class="dash-main">
        <h1 class="dash-title">Data Transaksi</h1>

        <!-- FORM TAMBAH / EDIT -->
        <section class="crud-card">
          <h2 class="dash-subtitle" id="form-title">Tambah Transaksi</h2>
          <form id="form-transaksi" class="crud-form" action="#" method="post">
            <input type="hidden" id="transaksi-id">

            <div class="crud-fields">
              <div class="form-group">
                <label for="tanggal">Tanggal</label>
                <input type="date" id="tanggal" required>
              </div>

              <div class="form-group">
                <label for="pembeli">Nama Pembeli</label>
                <input type="text" id="pembeli" placeholder="Masukan nama pembeli" maxlength="80" required>
              </div>

              <div class="form-group">
                <label for="hunian">Nama Hunian</label>
                <input type="text" id="hunian" placeholder="Contoh: Modern Minimalis" maxlength="80" required>
              </div>

              <div class="form-group">
                <label for="kategori">Kategori</label>
                <select id="kategori" required></select>
              </div>

              <div class="form-group">
                <label for="harga">Harga (Rp)</label>
                <input type="number" id="harga" placeholder="Contoh: 500000000" min="0" step="1" required>
              </div>

              <div class="form-group">
                <label for="status">Status</label>
                <select id="status" required>
                  <option value="Pending">Pending</option>
                  <option value="Lunas">Lunas</option>
                  <option value="Batal">Batal</option>
                </select>
              </div>
            </div>

            <div class="crud-actions">
              <button type="submit" class="btn btn-primary" id="btn-simpan">Simpan</button>
              <button type="button" class="btn btn-light" id="btn-batal">Batal</button>
            </div>
          </form>
        </section>

        <!-- DAFTAR -->
        <section>
          <div class="crud-toolbar">
            <h2 class="dash-subtitle">Daftar Transaksi</h2>
            <div class="dash-search crud-search">
              <input type="text" id="cari" placeholder="Cari transaksi....." aria-label="Cari transaksi">
            </div>
          </div>

          <div class="table-wrap">
            <table class="table table-lg">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Tanggal</th>
                  <th>Pembeli</th>
                  <th>Hunian</th>
                  <th>Kategori</th>
                  <th>Harga</th>
                  <th>Status</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody id="tabel-transaksi"></tbody>
            </table>
          </div>
          <p class="crud-summary" id="ringkasan"></p>
        </section>
      </main>

    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/transaksi.js"></script>
</body>
</html>