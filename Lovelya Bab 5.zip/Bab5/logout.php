<?php
// logout.php - menghapus session lalu kembali ke halaman login
session_start();

$_SESSION = [];                       // kosongkan data session

if (ini_get('session.use_cookies')) { // hapus cookie PHPSESSID di browser
    $p = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
}

session_destroy();                    // hancurkan session di server

header('Location: login.php?logout=1');
exit;