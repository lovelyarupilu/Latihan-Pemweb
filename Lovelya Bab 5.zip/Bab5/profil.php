<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Profil - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <img class="dash-avatar dash-avatar-img" src="images/profil.jpg" alt="Foto profil">
      </a>
    </header>

    <div class="dash-body">

      <!-- SIDEBAR -->
      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link active"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <main class="dash-main">
        <h1 class="dash-title">Profil</h1>

        <div class="profil-layout">

          <!-- FOTO + NAMA -->
          <section class="profil-photo">
            <div class="profil-photo-wrap">
              <img class="profil-photo-img" src="images/profil.jpg" alt="Foto profil">
              <button type="button" class="profil-photo-btn">Ubah Foto</button>
            </div>
            <p class="profil-name"><?= h(nama_user()) ?></p>
          </section>

          <!-- DATA DIRI -->
          <section class="profil-info">
            <ul class="profil-list">
              <li class="profil-row">
                <div class="profil-row-text">
                  <span class="profil-label">Nama Lengkap :</span>
                  <span class="profil-value"><?= h(nama_user()) ?></span>
                </div>
                <svg class="profil-icon" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M3 17.25V21h3.75L17.8 9.94l-3.75-3.75zM20.7 7.04a1 1 0 0 0 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75z" fill="#1f3a93"/>
                </svg>
              </li>

              <li class="profil-row">
                <div class="profil-row-text">
                  <span class="profil-label">Email :</span>
                  <span class="profil-value"><?= h(email_user()) ?></span>
                </div>
                <svg class="profil-icon" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M3 5h18a1 1 0 0 1 1 1v12a1 1 0 0 1-1 1H3a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1zm9 7L4 7v2l8 5 8-5V7z" fill="#1f3a93"/>
                </svg>
              </li>

              <li class="profil-row">
                <div class="profil-row-text">
                  <span class="profil-label">Nomor Telefon :</span>
                  <span class="profil-value">081122334455</span>
                </div>
                <svg class="profil-icon" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M6.6 10.8a15 15 0 0 0 6.6 6.6l2.2-2.2a1 1 0 0 1 1-.25 11.4 11.4 0 0 0 3.6.57 1 1 0 0 1 1 1V20a1 1 0 0 1-1 1A17 17 0 0 1 3 4a1 1 0 0 1 1-1h3.5a1 1 0 0 1 1 1c0 1.25.2 2.45.57 3.6a1 1 0 0 1-.25 1z" fill="#1f3a93"/>
                </svg>
              </li>

              <li class="profil-row">
                <div class="profil-row-text">
                  <span class="profil-label">Alamat :</span>
                  <span class="profil-value">Jl.Golf 73</span>
                </div>
                <svg class="profil-icon" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M12 2a7 7 0 0 0-7 7c0 5 7 13 7 13s7-8 7-13a7 7 0 0 0-7-7zm0 9.5A2.5 2.5 0 1 1 12 6.500a2.5 2.5 0 0 1 0 5z" fill="#1f3a93"/>
                </svg>
              </li>
            </ul>

            <div class="profil-actions">
              <a href="#" class="btn btn-dark">Edit Profil</a>
              <a href="#" class="btn btn-dark">Ubah Kata Sandi</a>
              <a href="logout.php" class="profil-logout">Keluar</a>
            </div>
          </section>

        </div>
      </main>

    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/profil.js"></script>
</body>
</html>