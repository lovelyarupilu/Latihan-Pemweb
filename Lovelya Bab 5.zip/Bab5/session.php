<?php
// session.php - dipanggil paling atas di setiap halaman yang memakai session
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Akun demo (selalu tersedia)
const AKUN_DEMO_EMAIL = 'vey@gmail.com';
const AKUN_DEMO_PASS  = '123456';
const AKUN_DEMO_NAMA  = 'Vey Jeanin';

function sudah_login(): bool {
    return isset($_SESSION['user']);
}

// Panggil di halaman yang wajib login
function wajib_login(): void {
    if (!sudah_login()) {
        header('Location: login.php');
        exit;
    }
}

function nama_user(): string {
    return $_SESSION['user']['nama'] ?? 'Tamu';
}

function email_user(): string {
    return $_SESSION['user']['email'] ?? '';
}

// Escape output supaya aman dari XSS
function h(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}