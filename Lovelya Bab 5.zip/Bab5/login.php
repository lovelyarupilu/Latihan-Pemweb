<?php
require 'session.php';

// Sudah login? langsung ke dashboard
if (sudah_login()) {
    header('Location: dashboard.php');
    exit;
}

$error = '';
$info  = '';
// Cookie: ingat email terakhir yang dipakai login
$emailIsi = $_COOKIE['email_terakhir'] ?? '';

if (isset($_GET['logout'])) $info = 'Anda sudah keluar.';
if (isset($_GET['daftar'])) $info = 'Pendaftaran berhasil, silakan masuk.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = strtolower(trim($_POST['email'] ?? ''));
    $pass  = $_POST['password'] ?? '';
    $emailIsi = $email;
    $nama = null;

    if ($email === AKUN_DEMO_EMAIL && $pass === AKUN_DEMO_PASS) {
        $nama = AKUN_DEMO_NAMA;
    } elseif (isset($_SESSION['akun'][$email]) &&
              password_verify($pass, $_SESSION['akun'][$email]['hash'])) {
        $nama = $_SESSION['akun'][$email]['nama'];
    }

    if ($nama !== null) {
        session_regenerate_id(true);
        $_SESSION['user'] = ['nama' => $nama, 'email' => $email];
        // simpan email di cookie selama 7 hari
        setcookie('email_terakhir', $email, time() + 7 * 24 * 3600, '/');
        header('Location: dashboard.php');
        exit;
    }
    $error = 'Email atau kata sandi salah.';
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Masuk - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body class="login-page">

  <main class="login-card">

    <header class="login-header">
      <a href="index.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
    </header>

    <h1 class="login-banner">Masuk ke HunianKu</h1>

    <form class="login-form" action="login.php" method="post">
      <?php if ($info): ?>
        <p class="register" style="color:#1b7a3a;margin-bottom:10px;"><?= h($info) ?></p>
      <?php endif; ?>

      <div class="form-group">
        <label for="email">Email</label>
        <input type="email" id="email" name="email" placeholder="Masukan email Anda" value="<?= h($emailIsi) ?>" required>
      </div>

      <div class="form-group">
        <label for="password">Kata Sandi</label>
        <input type="password" id="password" name="password" placeholder="Masukan kata sandi" required>
      </div>

      <p class="login-error" id="login-error" role="alert" <?= $error ? '' : 'hidden' ?>><?= h($error) ?></p>

      <button type="submit" class="btn-login">Masuk</button>

      <a href="#" class="forgot">Lupa Kata Sandi ?</a>

      <hr class="divider">

      <p class="register">Akun demo: Vey@gmail.com / 123456</p>

      <p class="register">Belum punya akun ? <a href="register.php">Daftar</a></p>
    </form>

  </main>
  <script src="js/common.js"></script>
</body>
</html>