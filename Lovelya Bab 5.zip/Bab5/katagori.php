<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Kategori - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <img class="dash-avatar dash-avatar-img" src="images/profil.jpg" alt="Foto profil">
      </a>
    </header>

    <div class="dash-body">

      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link active"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <main class="dash-main">
        <h1 class="dash-title">Data Kategori</h1>

        <!-- DAFTAR -->
        <section>
          <div class="crud-toolbar">
            <h2 class="dash-subtitle">Daftar Kategori</h2>
            <div class="dash-search crud-search">
              <input type="text" id="cari" placeholder="Cari kategori....." aria-label="Cari kategori">
            </div>
            <a href="katagoriEntry.php" class="btn btn-primary">+ Entry Kategori</a>
          </div>

          <div class="table-wrap">
            <table class="table">
              <thead>
                <tr>
                  <th>No</th>
                  <th>Nama</th>
                  <th>Deskripsi</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody id="tabel-kategori"></tbody>
            </table>
          </div>
          <p class="crud-summary" id="ringkasan"></p>
        </section>
      </main>

    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/kategori.js"></script>
</body>
</html>