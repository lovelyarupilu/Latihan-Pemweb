<?php require 'session.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="page">

    <!-- HEADER -->
    <header class="header">
      <a href="index.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <nav class="header-auth">
        <?php if (sudah_login()): ?>
          <a href="dashboard.php" class="header-link">Halo, <?= h(nama_user()) ?></a>
          <a href="logout.php" class="header-link header-link-primary">Keluar</a>
        <?php else: ?>
          <a href="login.php" class="header-link">Masuk</a>
          <a href="register.php" class="header-link header-link-primary">Daftar</a>
        <?php endif; ?>
      </nav>
    </header>

    <!-- HERO -->
    <section class="hero">
      <h1 class="hero-title">Temukan Hunian Idamanmu!</h1>
      <p class="hero-subtitle" id="sapaan">Rekomendasi Hunian sebagai referensimu</p>

      <div class="hero-image">
        <form class="search-box" id="formCari" action="#" method="get">
          <div class="search-row">
            <select name="lokasi" id="lokasi" aria-label="Lokasi">
              <option value="">Lokasi</option>
              <option>Bandung</option>
              <option>Bogor</option>
              <option>Jakarta</option>
              <option>Malang</option>
            </select>
            <select name="tipe" id="tipe" aria-label="Tipe Hunian">
              <option value="">Tipe Hunian</option>
              <option>Rumah</option>
              <option>Apartemen</option>
              <option>Villa</option>
            </select>
          </div>
          <div class="search-row">
            <select name="harga" id="harga" aria-label="Harga">
              <option value="">Harga</option>
              <option>&lt; Rp 500 Juta</option>
              <option>Rp 500 Juta - 1 M</option>
              <option>&gt; Rp 1 M</option>
            </select>
            <select name="perumahan" id="perumahan" aria-label="Perumahan">
              <option value="">Perumahan</option>
              <option>Cluster A</option>
              <option>Cluster B</option>
            </select>
            <button type="submit" class="btn-search">
              Cari Hunian
              <svg viewBox="0 0 24 24" width="12" height="12" aria-hidden="true">
                <circle cx="10" cy="10" r="6" fill="none" stroke="#fff" stroke-width="3"/>
                <line x1="15" y1="15" x2="22" y2="22" stroke="#fff" stroke-width="3" stroke-linecap="round"/>
              </svg>
            </button>
          </div>
        </form>
      </div>
    </section>

    <!-- REKOMENDASI -->
    <section class="recommend">
      <h2 class="section-title"><span>Rekomendasi Hunian</span></h2>

      <p class="hasil-cari" id="hasilCari"></p>

      <div class="card-list" id="daftarHunian">
        <article class="card">
          <img src="images/modern-minimalis.jpg" alt="Modern Minimalis">
          <h3 class="card-name">Modern Minimalis</h3>
          <div class="card-info">
            <span class="card-city">Bandung</span>
            <span class="card-price">Rp. 30.000.000.000</span>
          </div>
        </article>

        <article class="card">
          <img src="images/american-modern.jpg" alt="American Modern">
          <h3 class="card-name">American Modern</h3>
          <div class="card-info">
            <span class="card-city">Bogor</span>
            <span class="card-price">Rp. 35.000.000.000</span>
          </div>
        </article>
      </div>

      <a href="login.php" class="btn-all" id="btnLihat">Lihat Semua</a>
    </section>

  </div>

  <!-- JavaScript eksternal (diletakkan di bawah body agar loading halaman tidak terhambat) -->
  <script src="js/common.js"></script>
  <script src="js/index.js"></script>
</body>
</html>