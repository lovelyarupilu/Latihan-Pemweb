<?php require 'session.php'; wajib_login(); ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pesan - HunianKu</title>
  <link rel="stylesheet" href="style.css">
</head>
<body>
  <div class="dash">

    <header class="dash-header">
      <a href="dashboard.php" class="logo">
        <svg class="logo-icon" viewBox="0 0 24 24" aria-hidden="true">
          <path d="M12 2 1 11h3v10h6v-6h4v6h6V11h3z" fill="#1f5fa8"/>
        </svg>
        <span class="logo-text">HunianKu</span>
      </a>
      <a href="profil.php" class="dash-profile">
        <span><?= h(nama_user()) ?></span>
        <svg class="dash-avatar" viewBox="0 0 32 32" aria-hidden="true">
          <circle cx="16" cy="16" r="16" fill="#d9d9d9"/>
          <circle cx="16" cy="12" r="5.5" fill="#666"/>
          <path d="M5 28c1.5-6 6-8.5 11-8.5S25.5 22 27 28" fill="#666"/>
        </svg>
      </a>
    </header>

    <div class="dash-body">
      <!-- SIDEBAR -->
      <aside class="dash-sidebar">
        <nav>
          <a href="dashboard.php" class="dash-link"><i></i>Beranda</a>
          <a href="katagori.php" class="dash-link"><i></i>Kategori</a>
          <a href="transaksi.php" class="dash-link"><i></i>Transaksi</a>
          <a href="pesan.php" class="dash-link active"><i></i>Pesan</a>
          <a href="profil.php" class="dash-link"><i></i>Profil</a>
          <a href="logout.php" class="dash-link"><i></i>Keluar</a>
        </nav>
      </aside>

      <main class="dash-main">
        <h1 class="dash-title">Pesan Kamu</h1>

        <div class="pesan-layout">

          <!-- DAFTAR PERCAKAPAN -->
          <section class="pesan-side">
            <h2 class="dash-subtitle">Rekomendasi Harian Untukmu</h2>

            <div class="pesan-tabs">
              <button type="button" class="pesan-tab active">Pesan Masuk</button>
              <button type="button" class="pesan-tab">Draf Pesan</button>
            </div>

            <ul class="pesan-list">
              <li>
                <a href="#" class="pesan-item">
                  <img src="images/modern-minimalis.jpg" alt="Rumah Modern Minimalis">
                  <div class="pesan-item-text">
                    <strong>Rumah<br>Modern Minimalis</strong>
                    <span>Admin Rumah Modern Minimalis</span>
                  </div>
                </a>
              </li>
              <li>
                <a href="#" class="pesan-item active">
                  <img src="images/kost-premium.jpg" alt="Kost dekat Kampus">
                  <div class="pesan-item-text">
                    <strong>Kost dekat Kampus</strong>
                    <span>Admin Kost Dekat Kampus</span>
                  </div>
                  <svg class="pesan-check" viewBox="0 0 24 24" aria-hidden="true">
                    <circle cx="12" cy="12" r="11" fill="#1f3a93"/>
                    <path d="M6.5 12.5l3.5 3.5 7.5-8" fill="none" stroke="#fff" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
                  </svg>
                </a>
              </li>
            </ul>
          </section>

          <!-- RUANG CHAT -->
          <section class="pesan-chat">
            <div class="pesan-bubbles">
              <div class="bubble bubble-out">
                <p>Halo, Apakah kost dekat kampus masih tersedia kamar kosong?</p>
                <svg class="bubble-read" viewBox="0 0 24 24" aria-hidden="true">
                  <path d="M1.5 13l4 4 8-9M10 16l1 1 9-10" fill="none" stroke="#1f3a93" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
                </svg>
              </div>

              <div class="bubble bubble-in">
                <p>Halo, Masih Tersedia kak, apakah mau survey terlebih dahulu?</p>
              </div>
            </div>

            <form class="pesan-input" action="#" method="post">
              <input type="text" name="pesan" placeholder="Tulis Pesan ..." aria-label="Tulis pesan" autocomplete="off">
              <button type="submit" aria-label="Kirim">
                <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M2 21l21-9L2 3v7l15 2-15 2z" fill="#1f3a93"/></svg>
              </button>
            </form>
          </section>

        </div>
      </main>
    </div>
  </div>
  <script src="js/common.js"></script>
  <script src="js/pesan.js"></script>
</body>
</html>